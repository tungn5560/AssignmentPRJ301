/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tungnh.registration;

import tungnh.utils.DBUtils;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author Admin
 */
public class RegistrationDAO implements Serializable {

    private static final String LOGIN = "select fullName, roleID, address, birthday, phone, email, status from tblUsers where userID=? and password=?";

    public RegistrationDTO checkLogin(String userID, String password) throws SQLException {
        RegistrationDTO reg = null;
        Connection conn = null;
        PreparedStatement stm = null;
        ResultSet rs = null;
        try {
            conn = DBUtils.makeConnection();
            if (conn != null) {
                
                stm = conn.prepareStatement(LOGIN);
                stm.setString(1, userID);
                stm.setString(2, password);
                rs = stm.executeQuery();
                if (rs.next()) {
                    String fullName = rs.getString("fullName");
                    String roleID = rs.getString("roleID");
                    String address = rs.getString("address");
                    Date birthday = rs.getDate("birthday");
                    String phone = rs.getString("phone");
                    String email = rs.getString("email");
                    String status = rs.getString("status");
                    reg = new RegistrationDTO(userID, password, fullName, roleID, address, (java.sql.Date) birthday, phone, email, status);
                }
            }
        } catch (Exception e) {
            System.out.print(e.toString());
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stm != null) {
                stm.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
        return reg;
    }
    List<RegistrationDTO> listAccounts;

    public List<RegistrationDTO> getListAccounts() {
        //bam get la auto ra
        return listAccounts;
    }

    public void searchLastname(String searchValue) throws SQLException, ClassNotFoundException {
        Connection con = null;
        PreparedStatement stm = null;
        ResultSet rs = null;
        try {
            //Open connection 
            con = DBUtils.makeConnection();
            //2.Tao chuoi ket noi/Create sql string
            String sql = "SELECT [username]\n"
                    + "      ,[password]\n"
                    + "      ,[name]\n"
                    + "      ,[isAdmin]\n"
                    + "  FROM [dbo].[Registration]\n"
                    + "  Where name like ?";
            //3.Prepared stm
            stm = con.prepareStatement(sql);
            stm.setString(1, "%" + searchValue + "%");
            //4.Excecute query
            rs = stm.executeQuery();
            while (rs.next()) {
                String username = rs.getString("username");
                String password = rs.getString("password");
                String name = rs.getString("name");
                boolean role = rs.getBoolean("isAdmin");
                // RegistrationDTO dto = new RegistrationDTO(username, password, name, role);
                if (listAccounts == null) {
                    listAccounts = new ArrayList<>();
                }
                //  listAccounts.add(dto);
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stm != null) {
                con.close();
            }
            if (con != null) {
                con.close();
            }
        }
    }

    public boolean deleteRecord(String pk) throws SQLException, ClassNotFoundException {
        Connection con = null;
        PreparedStatement stm = null;
        try {
            //Open connection 
            con = DBUtils.makeConnection();
            //2.Tao chuoi ket noi/Create sql string
            String sql = "DELETE FROM [dbo].[Registration]\n"
                    + "      WHERE username = ?";
            //3.Prepared stm
            stm = con.prepareStatement(sql);
            stm.setString(1, pk);
            //4.Excecute query
            int row = stm.executeUpdate();
            if (row > 0) {
                return true;
            }

        } finally {
            if (stm != null) {
                con.close();
            }
            if (con != null) {
                con.close();
            }
        }
        return false;
    }

    public boolean updatePassRole(String username, String pw, String lastname, boolean role) throws SQLException, ClassNotFoundException {
        Connection con = null;
        PreparedStatement stm = null;
        try {
            //Open connection 
            con = DBUtils.makeConnection();
            //2.Tao chuoi ket noi/Create sql string
            String sql = "UPDATE [dbo].[Registration]\n"
                    + "   SET [password] = ? \n"
                    + "      ,[name] = ?\n"
                    + "      ,[isAdmin] = ?\n"
                    + " WHERE username = ?";
            //3.Prepared stm
            stm = con.prepareStatement(sql);
            stm.setString(1, pw);
            stm.setString(2, lastname);
            stm.setBoolean(3, role);
            stm.setString(4, username);
            //4.Excecute query
            int row = stm.executeUpdate();
            if (row > 0) {
                return true;
            }

        } finally {
            if (stm != null) {
                con.close();
            }
            if (con != null) {
                con.close();
            }
        }
        return false;

    }

}

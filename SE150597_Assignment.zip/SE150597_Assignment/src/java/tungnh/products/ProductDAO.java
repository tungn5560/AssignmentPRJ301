/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tungnh.products;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import tungnh.utils.DBUtils;

/**
 *
 * @author dell
 */
public class ProductDAO {

    private static final String SEARCH = "SELECT [productID],[productName],[image],[price],[quantity],[categoryID],[startDate],[endDate]\n"
            + "             FROM [Assignment].[dbo].[tblProduct]\n"
            + "             WHERE productName like ?";
    private static final String SEARCHCATEGORY = "SELECT [productID],[productName],[image],[price],[quantity],[categoryID],[startDate],[endDate]\n"
            + "             FROM [Assignment].[dbo].[tblProduct]\n"
            + "             WHERE categoryID like ?";
    private static final String SELECT = "SELECT [productID],[productName],[image],[price],[quantity],[categoryID],[startDate],[endDate]\n"
            + "             FROM [Assignment].[dbo].[tblProduct]\n"
            + "             ORDER BY startDate ";
    private static final String UPDATE = "update tblProduct set productName=?, price=?, quantity=?, categoryID=?, startDate=?, endDate=? where productID=?";

    private static final SimpleDateFormat SDF = new SimpleDateFormat("yyyy/MM/dd");

    public void getListProduct() throws SQLException, ClassNotFoundException {

        Connection conn = null;
        PreparedStatement stm = null;
        ResultSet rs = null;
        try {
            //Open connection 
            conn = DBUtils.makeConnection();
            //2.Tao chuoi ket noi/Create sql string

            //3.Prepared stm
            stm = conn.prepareStatement(SELECT);

            //4.Excecute query
            rs = stm.executeQuery();
            while (rs.next()) {
                String productID = rs.getString("productID");
                String productName = rs.getString("productName");
                String image = rs.getString("image");
                int price = rs.getInt("price");
                int quantity = rs.getInt("quantity");
                String categoryID = rs.getString("categoryID");
                Date importDate = new Date(rs.getDate("startDate").getTime());
                Date usingDate = new Date(rs.getDate("endDate").getTime());
                ProductDTO dto = new ProductDTO(productID, productName, image, price, quantity, categoryID, importDate, usingDate);

                if (listProducts == null) {
                    listProducts = new ArrayList<>();
                }
                listProducts.add(dto);
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stm != null) {
                stm.close();
            }
            if (conn != null) {
                conn.close();
            }
        }

    }
    //these methods is for user only

    public void searchLastname(String searchValue) throws SQLException, ClassNotFoundException {
        Connection con = null;
        PreparedStatement stm = null;
        ResultSet rs = null;
        try {
            //Open connection 
            con = DBUtils.makeConnection();
            //2.Tao chuoi ket noi/Create sql string

            //3.Prepared stm
            stm = con.prepareStatement(SEARCH);
            stm.setString(1, "%" + searchValue + "%");
            //4.Excecute query
            rs = stm.executeQuery();
            while (rs.next()) {
                String productID = rs.getString("productID");
                String productName = rs.getString("productName");
                String image = rs.getString("image");
                int price = rs.getInt("price");
                int quantity = rs.getInt("quantity");
                String categoryID = rs.getString("categoryID");
                Date importDate = new Date(rs.getDate("startDate").getTime());
                Date usingDate = new Date(rs.getDate("endDate").getTime());
                ProductDTO dto = new ProductDTO(productID, productName, image, price, quantity, categoryID, importDate, usingDate);

                if (listProducts == null) {
                    listProducts = new ArrayList<>();
                }
                listProducts.add(dto);
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stm != null) {
                con.close();
            }
            if (con != null) {
                con.close();
            }
        }
    }

    public void searchCategory(String searchValue) throws SQLException, ClassNotFoundException {
        Connection con = null;
        PreparedStatement stm = null;
        ResultSet rs = null;
        try {
            //Open connection 
            con = DBUtils.makeConnection();
            //2.Tao chuoi ket noi/Create sql string

            //3.Prepared stm
            stm = con.prepareStatement(SEARCHCATEGORY);
            stm.setString(1, "%" + searchValue + "%");
            //4.Excecute query
            rs = stm.executeQuery();
            while (rs.next()) {
                String productID = rs.getString("productID");
                String productName = rs.getString("productName");
                String image = rs.getString("image");
                int price = rs.getInt("price");
                int quantity = rs.getInt("quantity");
                String categoryID = rs.getString("categoryID");
                Date importDate = new Date(rs.getDate("startDate").getTime());
                Date usingDate = new Date(rs.getDate("endDate").getTime());
                ProductDTO dto = new ProductDTO(productID, productName, image, price, quantity, categoryID, importDate, usingDate);

                if (listProducts == null) {
                    listProducts = new ArrayList<>();
                }
                listProducts.add(dto);
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stm != null) {
                con.close();
            }
            if (con != null) {
                con.close();
            }
        }
    }

    List<ProductDTO> listProducts;

    public boolean updateProduct(ProductDTO product) throws SQLException {
        boolean result = false;
        Connection conn = null;
        PreparedStatement stm = null;
        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                stm = conn.prepareStatement(UPDATE);
                stm.setString(1, product.getProductName());
                stm.setString(2, String.valueOf(product.getPrice()));
                stm.setString(3, String.valueOf(product.getQuantity()));
                stm.setString(4, product.getCategoryID());
                stm.setString(5, SDF.format(product.getStartDate()));
                stm.setString(6, SDF.format(product.getEndDate()));
                stm.setString(7, product.getProductID());
                result = stm.executeUpdate() > 0;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (stm != null) {
                stm.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
        return result;
    }

    public List<ProductDTO> getListProducts() {
        //bam get la auto ra
        return listProducts;
    }
}

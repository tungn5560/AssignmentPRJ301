/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tungnh.utils;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Admin
 */
public class DBUtils implements Serializable{
    //Class java nam ben phia java nen phai chuyen doi thanh bit
    //Nen phai implement serializable
    public static Connection makeConnection() throws ClassNotFoundException, SQLException{
        Connection conn = null;
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        String url = "jdbc:sqlserver://localhost:1433;databaseName=Assignment;"; 
        conn = DriverManager.getConnection(url, "sa", "123456");
        return conn;
    }
    public static void main(String[] args) {
         DBUtils dbutils = new DBUtils();
         try {
             if(dbutils.makeConnection() != null){
                 System.out.println("Connected database successfull");
             }else{
                 System.out.println("Failed to connect to database");
             }
         } catch (Exception ex) {
             Logger.getLogger(DBUtils.class.getName()).log(Level.SEVERE, null, ex);
         }
    }

    public static Connection getConnection() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
